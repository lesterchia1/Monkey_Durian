# Durian and Monkey > 2024-12-14 7:21am
https://universe.roboflow.com/created-new-project/durian-and-monkey

Provided by a Roboflow user
License: CC BY 4.0

